import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { 
  Calendar, 
  Users, 
  FileText, 
  CreditCard, 
  MessageSquare, 
  Eye,
  Activity,
  Clock,
  TrendingUp,
  Plus,
  Stethoscope,
  TestTube,
  UserCircle,
  ArrowLeft,
  Settings,
  CheckCircle,
  ExternalLink
} from 'lucide-react'
import ophthalmixLogo from './assets/OphthalmixLogo.jpg'
import ClinicalExamination from './components/ClinicalExamination'
import PreliminaryDiagnostics from './components/PreliminaryDiagnostics'
import PatientPortal from './components/PatientPortal'
import './App.css'

// Dashboard Component
function Dashboard() {
  const [stats] = useState({
    todayAppointments: 12,
    totalPatients: 1247,
    pendingNotes: 5,
    overduePayments: 3,
    unreadMessages: 8
  })

  const [todayAppointments] = useState([
    { id: 1, time: '09:00', patient: 'John Smith', type: 'Routine Exam', status: 'confirmed' },
    { id: 2, time: '10:30', patient: 'Sarah Johnson', type: 'Follow-up', status: 'checked-in' },
    { id: 3, time: '11:15', patient: 'Michael Brown', type: 'Emergency', status: 'waiting' },
    { id: 4, time: '14:00', patient: 'Emily Davis', type: 'Consultation', status: 'confirmed' },
  ])

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'bg-blue-100 text-blue-800'
      case 'checked-in': return 'bg-green-100 text-green-800'
      case 'waiting': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Reception Dashboard</h1>
        <div className="flex space-x-2">
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Quick Actions
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.todayAppointments}</div>
            <p className="text-xs text-muted-foreground">+2 from yesterday</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.totalPatients}</div>
            <p className="text-xs text-muted-foreground">+12 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Notes</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pendingNotes}</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Payments</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.overduePayments}</div>
            <p className="text-xs text-muted-foreground">Follow up needed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.unreadMessages}</div>
            <p className="text-xs text-muted-foreground">New messages</p>
          </CardContent>
        </Card>
      </div>

      {/* Today's Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="w-5 h-5 mr-2 text-primary" />
              Today's Schedule
            </CardTitle>
            <CardDescription>Upcoming appointments for today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="text-sm font-medium text-primary">{appointment.time}</div>
                    <div>
                      <div className="font-medium">{appointment.patient}</div>
                      <div className="text-sm text-gray-500">{appointment.type}</div>
                    </div>
                  </div>
                  <Badge className={getStatusColor(appointment.status)}>
                    {appointment.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-primary" />
              Quick Actions
            </CardTitle>
            <CardDescription>Common tasks and shortcuts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                <Users className="w-6 h-6 mb-2" />
                <span className="text-sm">New Patient</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                <Calendar className="w-6 h-6 mb-2" />
                <span className="text-sm">Book Appointment</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                <FileText className="w-6 h-6 mb-2" />
                <span className="text-sm">Clinical Note</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                <CreditCard className="w-6 h-6 mb-2" />
                <span className="text-sm">Process Payment</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Placeholder components for other sections
function AppointmentBooking() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Appointment Booking</h1>
      <Card>
        <CardHeader>
          <CardTitle>Schedule Management</CardTitle>
          <CardDescription>Book and manage patient appointments</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Appointment booking interface will be implemented here.</p>
        </CardContent>
      </Card>
    </div>
  )
}

function PatientRecords() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Patient Records</h1>
      <Card>
        <CardHeader>
          <CardTitle>Patient Management</CardTitle>
          <CardDescription>View and manage patient information</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Patient records interface will be implemented here.</p>
        </CardContent>
      </Card>
    </div>
  )
}

function ClinicalNotes() {
  return <ClinicalExamination patientId={1} appointmentId={1} />
}

function PreliminaryDiagnosticsPage() {
  return <PreliminaryDiagnostics patientId={1} examinationId={1} />
}

function PatientPortalPage() {
  return <PatientPortal />
}

function Billing() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedPatient, setSelectedPatient] = useState('')
  const [payerType, setPayerType] = useState('self-pay')
  const [selectedServices, setSelectedServices] = useState([])
  const [insurerDetails, setInsurerDetails] = useState({
    insurer: '',
    membershipNumber: '',
    authorisationCode: '',
    excessAmount: 0
  })

  const patients = [
    { id: '12345', name: 'John Smith', dob: '1975-03-15', nhsNumber: 'NHS123456789', insuranceId: 'BUPA001' },
    { id: '12346', name: 'Sarah Johnson', dob: '1982-07-22', nhsNumber: 'NHS987654321', insuranceId: 'AXA002' },
    { id: '12347', name: 'Michael Brown', dob: '1968-11-08', nhsNumber: 'NHS456789123', insuranceId: '' }
  ]

  const servicesTariff = [
    { code: 'CONS001', service: 'Initial Consultation', selfPay: 250, nhs: 180, category: 'Consultation' },
    { code: 'CONS002', service: 'Follow-up Consultation', selfPay: 180, nhs: 120, category: 'Consultation' },
    { code: 'OCT001', service: 'OCT Scan', selfPay: 150, nhs: 95, category: 'Imaging' },
    { code: 'VF001', service: 'Visual Field Test', selfPay: 120, nhs: 75, category: 'Testing' },
    { code: 'SURG001', service: 'Cataract Surgery', selfPay: 2500, nhs: 1800, category: 'Surgery' },
    { code: 'INJ001', service: 'Intravitreal Injection', selfPay: 800, nhs: 450, category: 'Procedure' }
  ]

  const insurers = [
    'Bupa', 'AXA Health', 'Vitality', 'Aviva', 'Simply Health', 'WPA', 'Cigna', 'Allianz Care'
  ]

  const outstandingBills = [
    { id: 'INV001', patient: 'John Smith', amount: 430, type: 'Self-Pay', date: '2025-09-01', status: 'Overdue' },
    { id: 'INV002', patient: 'Sarah Johnson', amount: 250, type: 'PMI', date: '2025-09-03', status: 'Pending' },
    { id: 'INV003', patient: 'Michael Brown', amount: 180, type: 'Self-Pay', date: '2025-09-04', status: 'Paid' }
  ]

  const addService = (service) => {
    if (!selectedServices.find(s => s.code === service.code)) {
      setSelectedServices([...selectedServices, { ...service, quantity: 1 }])
    }
  }

  const removeService = (code) => {
    setSelectedServices(selectedServices.filter(s => s.code !== code))
  }

  const calculateTotal = () => {
    return selectedServices.reduce((total, service) => {
      const price = payerType === 'self-pay' ? service.selfPay : service.nhs
      return total + (price * service.quantity)
    }, 0)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'Paid': return 'bg-green-100 text-green-800'
      case 'Pending': return 'bg-yellow-100 text-yellow-800'
      case 'Overdue': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Medical Billing System</h1>
          <p className="text-gray-600 mt-1">Self-Pay • PMI • NHS Billing Management</p>
        </div>
        <div className="flex space-x-2">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            NHS Compliant
          </Badge>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            PMI Integrated
          </Badge>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Activity },
            { id: 'new-invoice', label: 'New Invoice', icon: Plus },
            { id: 'outstanding', label: 'Outstanding Bills', icon: Clock },
            { id: 'reports', label: 'Reports', icon: FileText }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-4 h-4 mr-2" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Dashboard Tab */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <CreditCard className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Today's Revenue</p>
                    <p className="text-2xl font-semibold text-gray-900">£2,450</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Outstanding Bills</p>
                    <p className="text-2xl font-semibold text-gray-900">£8,750</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <FileText className="h-8 w-8 text-purple-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">PMI Claims</p>
                    <p className="text-2xl font-semibold text-gray-900">12</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Activity className="h-8 w-8 text-orange-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">NHS Claims</p>
                    <p className="text-2xl font-semibold text-gray-900">28</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {outstandingBills.slice(0, 5).map((bill) => (
                    <div key={bill.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium text-sm">{bill.patient}</p>
                        <p className="text-xs text-gray-500">{bill.id} • {bill.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">£{bill.amount}</p>
                        <Badge className={`text-xs ${getStatusColor(bill.status)}`}>
                          {bill.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payer Type Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Self-Pay</span>
                    <div className="flex items-center">
                      <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                        <div className="bg-blue-600 h-2 rounded-full" style={{width: '45%'}}></div>
                      </div>
                      <span className="text-sm text-gray-600">45%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">PMI</span>
                    <div className="flex items-center">
                      <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                        <div className="bg-green-600 h-2 rounded-full" style={{width: '35%'}}></div>
                      </div>
                      <span className="text-sm text-gray-600">35%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">NHS</span>
                    <div className="flex items-center">
                      <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                        <div className="bg-purple-600 h-2 rounded-full" style={{width: '20%'}}></div>
                      </div>
                      <span className="text-sm text-gray-600">20%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* New Invoice Tab */}
      {activeTab === 'new-invoice' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Invoice Creation Form */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Create New Invoice</CardTitle>
                <CardDescription>Generate invoices for Self-Pay, PMI, or NHS patients</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Patient Selection */}
                <div>
                  <Label className="text-sm font-medium text-gray-700">Patient</Label>
                  <select 
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={selectedPatient}
                    onChange={(e) => setSelectedPatient(e.target.value)}
                  >
                    <option value="">Select Patient</option>
                    {patients.map((patient) => (
                      <option key={patient.id} value={patient.id}>
                        {patient.name} (#{patient.id}) - NHS: {patient.nhsNumber}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Payer Type Selection */}
                <div>
                  <Label className="text-sm font-medium text-gray-700">Payer Type</Label>
                  <div className="mt-2 space-x-4">
                    {[
                      { id: 'self-pay', label: 'Self-Pay', color: 'blue' },
                      { id: 'pmi', label: 'PMI', color: 'green' },
                      { id: 'nhs', label: 'NHS', color: 'purple' }
                    ].map((type) => (
                      <label key={type.id} className="inline-flex items-center">
                        <input
                          type="radio"
                          name="payerType"
                          value={type.id}
                          checked={payerType === type.id}
                          onChange={(e) => setPayerType(e.target.value)}
                          className={`form-radio text-${type.color}-600`}
                        />
                        <span className="ml-2 text-sm">{type.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* PMI Details (if PMI selected) */}
                {payerType === 'pmi' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-green-50 rounded-lg">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Insurer</Label>
                      <select 
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                        value={insurerDetails.insurer}
                        onChange={(e) => setInsurerDetails({...insurerDetails, insurer: e.target.value})}
                      >
                        <option value="">Select Insurer</option>
                        {insurers.map((insurer) => (
                          <option key={insurer} value={insurer}>{insurer}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Membership Number</Label>
                      <Input 
                        placeholder="Enter membership number"
                        value={insurerDetails.membershipNumber}
                        onChange={(e) => setInsurerDetails({...insurerDetails, membershipNumber: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Authorisation Code</Label>
                      <Input 
                        placeholder="Enter auth code"
                        value={insurerDetails.authorisationCode}
                        onChange={(e) => setInsurerDetails({...insurerDetails, authorisationCode: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Patient Excess (£)</Label>
                      <Input 
                        type="number"
                        placeholder="0"
                        value={insurerDetails.excessAmount}
                        onChange={(e) => setInsurerDetails({...insurerDetails, excessAmount: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>
                )}

                {/* Services Selection */}
                <div>
                  <Label className="text-sm font-medium text-gray-700">Services & Procedures</Label>
                  <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                    {servicesTariff.map((service) => (
                      <button
                        key={service.code}
                        onClick={() => addService(service)}
                        className="text-left p-3 border rounded hover:bg-gray-50 transition-colors"
                      >
                        <div className="font-medium text-sm">{service.service}</div>
                        <div className="text-xs text-gray-500">{service.code} • {service.category}</div>
                        <div className="text-sm font-semibold text-blue-600">
                          £{payerType === 'self-pay' ? service.selfPay : service.nhs}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Selected Services */}
                {selectedServices.length > 0 && (
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Selected Services</Label>
                    <div className="mt-2 space-y-2">
                      {selectedServices.map((service) => (
                        <div key={service.code} className="flex items-center justify-between p-3 bg-blue-50 rounded">
                          <div>
                            <span className="font-medium text-sm">{service.service}</span>
                            <span className="text-xs text-gray-500 ml-2">({service.code})</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="font-semibold">
                              £{payerType === 'self-pay' ? service.selfPay : service.nhs}
                            </span>
                            <button
                              onClick={() => removeService(service.code)}
                              className="text-red-600 hover:text-red-800"
                            >
                              ×
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="border-t pt-2">
                        <div className="flex justify-between items-center font-bold">
                          <span>Total:</span>
                          <span className="text-lg">£{calculateTotal()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex space-x-3">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Invoice
                  </Button>
                  <Button variant="outline">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                  {payerType === 'pmi' && (
                    <Button variant="outline" className="bg-green-50 border-green-200 text-green-700">
                      Submit to Insurer
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions & Info */}
            <div className="space-y-6">
              {/* Compliance Checklist */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Compliance Checklist</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">NHS Tariff Integration</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">OPCS/ICD Coding</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">VAT Compliance</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Audit Trail</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">EDI Integration</span>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Today's Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Invoices Created</span>
                    <span className="font-semibold">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Payments Received</span>
                    <span className="font-semibold">£1,250</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">PMI Claims Sent</span>
                    <span className="font-semibold">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">NHS Claims</span>
                    <span className="font-semibold">5</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}

      {/* Outstanding Bills Tab */}
      {activeTab === 'outstanding' && (
        <Card>
          <CardHeader>
            <CardTitle>Outstanding Bills Management</CardTitle>
            <CardDescription>Track and manage unpaid invoices across all payer types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {outstandingBills.map((bill) => (
                <div key={bill.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4">
                      <div>
                        <p className="font-medium">{bill.patient}</p>
                        <p className="text-sm text-gray-500">{bill.id} • {bill.date}</p>
                      </div>
                      <Badge className={getStatusColor(bill.status)}>
                        {bill.status}
                      </Badge>
                      <Badge variant="outline">
                        {bill.type}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-lg font-semibold">£{bill.amount}</span>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Record Payment
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reports Tab */}
      {activeTab === 'reports' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Daily Revenue Summary
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Payer Type Analysis
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Aged Debt Report
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-2" />
                NHS Claims Summary
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Export & Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start">
                <Activity className="w-4 h-4 mr-2" />
                Export to Xero
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Activity className="w-4 h-4 mr-2" />
                Export to Sage
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Activity className="w-4 h-4 mr-2" />
                SUS Data Submission
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Activity className="w-4 h-4 mr-2" />
                PMI Batch Submission
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

function TeamMessenger() {
  const [activeChannel, setActiveChannel] = useState('general')
  const [newMessage, setNewMessage] = useState('')
  const [messages, setMessages] = useState({
    general: [
      { id: 1, user: 'Dr. Adams', message: 'Good morning team! Ready for today\'s appointments.', time: '09:15', avatar: 'DA' },
      { id: 2, user: 'Sarah (Nurse)', message: 'Morning! Patient prep is complete for the 10:30 slot.', time: '09:18', avatar: 'SN' },
      { id: 3, user: 'Mike (Reception)', message: 'We have a walk-in emergency. Can we fit them in?', time: '09:22', avatar: 'MR' }
    ],
    clinical: [
      { id: 1, user: 'Dr. Adams', message: 'Please review the OCT results for patient #1247', time: '08:45', avatar: 'DA' },
      { id: 2, user: 'Dr. Smith', message: 'Results look concerning. Scheduling follow-up.', time: '08:50', avatar: 'DS' }
    ],
    admin: [
      { id: 1, user: 'Admin', message: 'System maintenance scheduled for tonight 11 PM - 1 AM', time: '08:30', avatar: 'AD' }
    ]
  })

  const channels = [
    { id: 'general', name: 'General', icon: '💬', unread: 0 },
    { id: 'clinical', name: 'Clinical Updates', icon: '🏥', unread: 2 },
    { id: 'admin', name: 'Admin Notices', icon: '📋', unread: 1 },
    { id: 'emergency', name: 'Emergency', icon: '🚨', unread: 0 }
  ]

  const onlineUsers = [
    { name: 'Dr. Adams', status: 'online', avatar: 'DA', role: 'Consultant' },
    { name: 'Sarah (Nurse)', status: 'online', avatar: 'SN', role: 'Nurse' },
    { name: 'Mike (Reception)', status: 'online', avatar: 'MR', role: 'Reception' },
    { name: 'Dr. Smith', status: 'away', avatar: 'DS', role: 'Consultant' },
    { name: 'Lisa (Admin)', status: 'offline', avatar: 'LA', role: 'Administrator' }
  ]

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message = {
        id: Date.now(),
        user: 'You',
        message: newMessage,
        time: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
        avatar: 'YU'
      }
      setMessages(prev => ({
        ...prev,
        [activeChannel]: [...(prev[activeChannel] || []), message]
      }))
      setNewMessage('')
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-500'
      case 'away': return 'bg-yellow-500'
      case 'offline': return 'bg-gray-400'
      default: return 'bg-gray-400'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Team Messenger</h1>
        <Badge variant="outline" className="text-sm px-3 py-1 bg-blue-50 text-blue-700 border-blue-200">
          Internal Communication Platform
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
        {/* Channels Sidebar */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Channels</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {channels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => setActiveChannel(channel.id)}
                className={`w-full flex items-center justify-between p-3 rounded-lg text-left transition-colors ${
                  activeChannel === channel.id
                    ? 'bg-blue-100 text-blue-800 border border-blue-200'
                    : 'hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{channel.icon}</span>
                  <span className="font-medium text-sm">{channel.name}</span>
                </div>
                {channel.unread > 0 && (
                  <Badge className="bg-red-500 text-white text-xs px-2 py-1">
                    {channel.unread}
                  </Badge>
                )}
              </button>
            ))}
            
            <div className="pt-4 border-t">
              <h4 className="font-semibold text-sm text-gray-700 mb-2">Online Now ({onlineUsers.filter(u => u.status === 'online').length})</h4>
              <div className="space-y-2">
                {onlineUsers.map((user, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-xs font-bold">
                        {user.avatar}
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(user.status)}`}></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-3 flex flex-col">
          <CardHeader className="pb-3 border-b">
            <div className="flex items-center space-x-2">
              <span className="text-xl">{channels.find(c => c.id === activeChannel)?.icon}</span>
              <CardTitle className="text-lg">{channels.find(c => c.id === activeChannel)?.name}</CardTitle>
            </div>
          </CardHeader>
          
          {/* Messages Area */}
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {(messages[activeChannel] || []).map((msg) => (
              <div key={msg.id} className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-xs font-bold text-blue-800">
                  {msg.avatar}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-medium text-sm text-gray-900">{msg.user}</span>
                    <span className="text-xs text-gray-500">{msg.time}</span>
                  </div>
                  <p className="text-sm text-gray-700 bg-gray-50 rounded-lg p-3">{msg.message}</p>
                </div>
              </div>
            ))}
          </CardContent>

          {/* Message Input */}
          <div className="border-t p-4">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder={`Message #${channels.find(c => c.id === activeChannel)?.name.toLowerCase()}`}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Button onClick={sendMessage} className="bg-blue-600 hover:bg-blue-700">
                <MessageSquare className="w-4 h-4 mr-2" />
                Send
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center">
              <Users className="w-4 h-4 mr-2 text-blue-600" />
              Team Directory
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-gray-600 mb-2">Quick access to team contacts</p>
            <Button variant="outline" size="sm" className="w-full">
              View All Staff
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center">
              <Calendar className="w-4 h-4 mr-2 text-green-600" />
              Schedule Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-gray-600 mb-2">Share schedule changes instantly</p>
            <Button variant="outline" size="sm" className="w-full">
              Post Update
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center">
              <FileText className="w-4 h-4 mr-2 text-purple-600" />
              File Sharing
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-gray-600 mb-2">Share documents and images</p>
            <Button variant="outline" size="sm" className="w-full">
              Upload File
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function OptiScribe() {
  const [activeTab, setActiveTab] = useState('prescribe')
  const [selectedMedication, setSelectedMedication] = useState('')
  const [dosage, setDosage] = useState('')
  const [frequency, setFrequency] = useState('')
  const [duration, setDuration] = useState('')

  const commonMedications = [
    { name: 'Latanoprost 0.005%', category: 'Glaucoma', indication: 'Reduce intraocular pressure' },
    { name: 'Timolol 0.5%', category: 'Glaucoma', indication: 'Beta-blocker for IOP reduction' },
    { name: 'Prednisolone 1%', category: 'Anti-inflammatory', indication: 'Post-operative inflammation' },
    { name: 'Chloramphenicol 0.5%', category: 'Antibiotic', indication: 'Bacterial conjunctivitis' },
    { name: 'Cyclopentolate 1%', category: 'Mydriatic', indication: 'Pupil dilation for examination' },
    { name: 'Artificial Tears', category: 'Lubricant', indication: 'Dry eye syndrome' }
  ]

  const recentPrescriptions = [
    { patient: 'John Smith', medication: 'Latanoprost 0.005%', date: '2025-09-05', status: 'Active' },
    { patient: 'Sarah Johnson', medication: 'Prednisolone 1%', date: '2025-09-04', status: 'Completed' },
    { patient: 'Michael Brown', medication: 'Timolol 0.5%', date: '2025-09-03', status: 'Active' }
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">OptiScribe</h1>
          <p className="text-lg text-blue-600 font-semibold mt-1">World's Best Prescribing Module</p>
        </div>
        <div className="text-right">
          <Badge variant="outline" className="text-sm px-4 py-2 bg-green-50 text-green-700 border-green-200 mb-2">
            NHS Compliant Prescribing Module
          </Badge>
          <p className="text-xs text-gray-500">Fully integrated with NHS guidelines</p>
        </div>
      </div>

      {/* Feature Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-blue-800">Smart Prescribing</h3>
            <p className="text-xs text-blue-600 mt-1">AI-powered medication suggestions</p>
          </CardContent>
        </Card>
        
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-green-800">NHS Compliant</h3>
            <p className="text-xs text-green-600 mt-1">Meets all regulatory standards</p>
          </CardContent>
        </Card>
        
        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-purple-800">Ophthalmic Focus</h3>
            <p className="text-xs text-purple-600 mt-1">Specialized for eye care</p>
          </CardContent>
        </Card>
        
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-orange-800">Real-time Checks</h3>
            <p className="text-xs text-orange-600 mt-1">Drug interactions & allergies</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Prescription Form */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-blue-600" />
              New Prescription
            </CardTitle>
            <CardDescription>Create NHS-compliant prescriptions with intelligent suggestions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-700">Patient</Label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                  <option>Select Patient</option>
                  <option>John Smith (#12345)</option>
                  <option>Sarah Johnson (#12346)</option>
                  <option>Michael Brown (#12347)</option>
                </select>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700">Medication</Label>
                <select 
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={selectedMedication}
                  onChange={(e) => setSelectedMedication(e.target.value)}
                >
                  <option value="">Select Medication</option>
                  {commonMedications.map((med, index) => (
                    <option key={index} value={med.name}>{med.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-700">Dosage</Label>
                <Input 
                  placeholder="e.g., 1 drop"
                  value={dosage}
                  onChange={(e) => setDosage(e.target.value)}
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700">Frequency</Label>
                <select 
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value)}
                >
                  <option value="">Select Frequency</option>
                  <option value="once_daily">Once Daily</option>
                  <option value="twice_daily">Twice Daily</option>
                  <option value="three_times">Three Times Daily</option>
                  <option value="four_times">Four Times Daily</option>
                  <option value="as_needed">As Needed</option>
                </select>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700">Duration</Label>
                <select 
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                >
                  <option value="">Select Duration</option>
                  <option value="7_days">7 Days</option>
                  <option value="14_days">14 Days</option>
                  <option value="1_month">1 Month</option>
                  <option value="3_months">3 Months</option>
                  <option value="ongoing">Ongoing</option>
                </select>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">Special Instructions</Label>
              <Textarea 
                placeholder="Additional instructions for patient..."
                className="mt-1"
              />
            </div>

            <div className="flex space-x-3">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <FileText className="w-4 h-4 mr-2" />
                Generate Prescription
              </Button>
              <Button variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button variant="outline">
                <Activity className="w-4 h-4 mr-2" />
                Check Interactions
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions & Info */}
        <div className="space-y-6">
          {/* Common Medications */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Common Medications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {commonMedications.slice(0, 4).map((med, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedMedication(med.name)}
                  className="w-full text-left p-2 hover:bg-gray-50 rounded border"
                >
                  <div className="font-medium text-sm text-gray-900">{med.name}</div>
                  <div className="text-xs text-gray-500">{med.category}</div>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* Recent Prescriptions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Recent Prescriptions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {recentPrescriptions.map((prescription, index) => (
                <div key={index} className="p-2 border rounded">
                  <div className="font-medium text-sm text-gray-900">{prescription.patient}</div>
                  <div className="text-xs text-gray-600">{prescription.medication}</div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-xs text-gray-500">{prescription.date}</span>
                    <Badge 
                      className={`text-xs ${
                        prescription.status === 'Active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {prescription.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* NHS Compliance Features */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <CheckCircle className="w-5 h-5 mr-2" />
            NHS Compliance Features
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">BNF Integration</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">NICE Guidelines</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">Drug Interaction Checks</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">Allergy Alerts</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">Electronic Prescribing</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-800">Audit Trail</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function BISuite() {
  const [currentView, setCurrentView] = useState('main')

  if (currentView === 'basic') {
    return <BIReports onBack={() => setCurrentView('main')} />
  }

  if (currentView === 'advanced') {
    return <AdvancedBIReports onBack={() => setCurrentView('main')} />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">BI Suite</h1>
        <Badge variant="outline" className="text-sm px-3 py-1 bg-teal-50 text-teal-700 border-teal-200">
          Business Intelligence Platform
        </Badge>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl">
        {/* Basic BI Reports */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentView('basic')}>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <TrendingUp className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-xl">Basic BI Reports</CardTitle>
            <CardDescription>Essential practice analytics and reporting</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <Activity className="w-4 h-4 mr-2 text-teal-600" />
                Activity & Patient Flow
              </div>
              <div className="flex items-center">
                <CreditCard className="w-4 h-4 mr-2 text-green-600" />
                Financial & Revenue Analysis
              </div>
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-2 text-purple-600" />
                Patient Demographics
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-2 text-orange-600" />
                Operational Efficiency
              </div>
            </div>
            <Button className="w-full mt-4" variant="outline">
              Access Basic Reports
            </Button>
          </CardContent>
        </Card>

        {/* Advanced BI Reports */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentView('advanced')}>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mb-4">
              <Eye className="w-8 h-8 text-teal-600" />
            </div>
            <CardTitle className="text-xl">Advanced BI Reports</CardTitle>
            <CardDescription>Comprehensive ophthalmology specialist analytics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <Eye className="w-4 h-4 mr-2 text-blue-600" />
                Clinical Outcomes & Quality
              </div>
              <div className="flex items-center">
                <FileText className="w-4 h-4 mr-2 text-red-600" />
                Regulatory & Compliance
              </div>
              <div className="flex items-center">
                <Activity className="w-4 h-4 mr-2 text-green-600" />
                Specialty Service Dashboards
              </div>
              <div className="flex items-center">
                <TrendingUp className="w-4 h-4 mr-2 text-purple-600" />
                NOD & SUS Reporting
              </div>
            </div>
            <Button className="w-full mt-4" variant="outline">
              Access Advanced Reports
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function BIReports({ onBack }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Basic BI Reports</h1>
        {onBack && (
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to BI Suite
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Activity Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-teal-600" />
              Activity Reports
            </CardTitle>
            <CardDescription>Patient flow and appointment analytics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Calendar className="w-4 h-4 mr-2" />
              Daily Activity Summary
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Users className="w-4 h-4 mr-2" />
              Patient Volume Trends
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Clock className="w-4 h-4 mr-2" />
              Appointment Efficiency
            </Button>
          </CardContent>
        </Card>

        {/* Financial Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-green-600" />
              Financial Reports
            </CardTitle>
            <CardDescription>Revenue and billing analytics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <TrendingUp className="w-4 h-4 mr-2" />
              Revenue Analysis
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="w-4 h-4 mr-2" />
              Outstanding Invoices
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <CreditCard className="w-4 h-4 mr-2" />
              Payment Methods
            </Button>
          </CardContent>
        </Card>

        {/* Clinical Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Stethoscope className="w-5 h-5 mr-2 text-blue-600" />
              Clinical Reports
            </CardTitle>
            <CardDescription>Medical outcomes and procedures</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Eye className="w-4 h-4 mr-2" />
              Procedure Statistics
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <TestTube className="w-4 h-4 mr-2" />
              Diagnostic Outcomes
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="w-4 h-4 mr-2" />
              Treatment Effectiveness
            </Button>
          </CardContent>
        </Card>

        {/* Operational Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
              Operational Reports
            </CardTitle>
            <CardDescription>Practice efficiency metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Users className="w-4 h-4 mr-2" />
              Staff Performance
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Clock className="w-4 h-4 mr-2" />
              Wait Time Analysis
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Activity className="w-4 h-4 mr-2" />
              Resource Utilization
            </Button>
          </CardContent>
        </Card>

        {/* Patient Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <UserCircle className="w-5 h-5 mr-2 text-orange-600" />
              Patient Reports
            </CardTitle>
            <CardDescription>Patient demographics and satisfaction</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Users className="w-4 h-4 mr-2" />
              Demographics Analysis
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <MessageSquare className="w-4 h-4 mr-2" />
              Satisfaction Scores
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Calendar className="w-4 h-4 mr-2" />
              Retention Rates
            </Button>
          </CardContent>
        </Card>

        {/* Custom Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="w-5 h-5 mr-2 text-red-600" />
              Custom Reports
            </CardTitle>
            <CardDescription>Build your own analytics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <Plus className="w-4 h-4 mr-2" />
              Create New Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="w-4 h-4 mr-2" />
              Saved Reports
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <TrendingUp className="w-4 h-4 mr-2" />
              Report Templates
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function AdvancedBIReports({ onBack }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-3xl font-bold text-gray-900">Advanced BI Reports</h1>
          <Badge variant="outline" className="text-sm px-3 py-1 bg-teal-50 text-teal-700 border-teal-200">
            Ophthalmology Specialist Suite
          </Badge>
        </div>
        {onBack && (
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to BI Suite
          </Button>
        )}
      </div>

      {/* NOD and SUS Reports Section */}
      <div className="bg-gradient-to-r from-blue-50 to-teal-50 p-6 rounded-lg border border-blue-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">NHS Reporting</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Reports for NOD */}
          <Card className="border-blue-200">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center text-blue-800">
                <FileText className="w-5 h-5 mr-2" />
                Reports for NOD
              </CardTitle>
              <CardDescription>National Ophthalmology Database submissions</CardDescription>
            </CardHeader>
            <CardContent className="pt-4 space-y-3">
              <Button variant="outline" className="w-full justify-start text-sm">
                <Eye className="w-4 h-4 mr-2" />
                Cataract Surgery Outcomes
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Activity className="w-4 h-4 mr-2" />
                Refractive Surgery Data
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                Visual Acuity Outcomes
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TestTube className="w-4 h-4 mr-2" />
                Complication Rates
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <FileText className="w-4 h-4 mr-2" />
                Patient Demographics
              </Button>
            </CardContent>
          </Card>

          {/* Reports for SUS */}
          <Card className="border-teal-200">
            <CardHeader className="bg-teal-50">
              <CardTitle className="flex items-center text-teal-800">
                <CreditCard className="w-5 h-5 mr-2" />
                Reports for SUS
              </CardTitle>
              <CardDescription>Secondary Uses Service data submissions</CardDescription>
            </CardHeader>
            <CardContent className="pt-4 space-y-3">
              <Button variant="outline" className="w-full justify-start text-sm">
                <Calendar className="w-4 h-4 mr-2" />
                Activity Data (APC/OP)
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Users className="w-4 h-4 mr-2" />
                Patient Demographics
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <FileText className="w-4 h-4 mr-2" />
                Procedure Codes (OPCS-4)
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Diagnosis Codes (ICD-10)
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Clock className="w-4 h-4 mr-2" />
                Waiting Times Data
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Clinical Outcomes & Quality Dashboard */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="w-5 h-5 mr-2 text-blue-600" />
              Clinical Outcomes & Quality
            </CardTitle>
            <CardDescription>Monitor patient outcomes, surgical safety, and treatment effectiveness</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Surgical Outcomes</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Eye className="w-4 h-4 mr-2" />
                Cataract Surgery Dashboard
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Activity className="w-4 h-4 mr-2" />
                Refractive Surgery Outcomes
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Disease Management</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                Glaucoma Management Dashboard
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TestTube className="w-4 h-4 mr-2" />
                Retina Outcomes Report
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Quality Assurance</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <FileText className="w-4 h-4 mr-2" />
                Clinical Audit Reports
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Operational Efficiency Dashboard */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-green-600" />
              Operational Efficiency
            </CardTitle>
            <CardDescription>Optimize clinic throughput and resource utilization</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Appointment Management</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Calendar className="w-4 h-4 mr-2" />
                DNA & Cancellation Rates
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Clock className="w-4 h-4 mr-2" />
                Average Waiting Times
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Clinic Productivity</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Users className="w-4 h-4 mr-2" />
                Patients per Session
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                New vs Follow-up Ratio
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Theatre & Diagnostics</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Activity className="w-4 h-4 mr-2" />
                Theatre Utilization
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TestTube className="w-4 h-4 mr-2" />
                Diagnostic Testing Volumes
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Financial & Revenue Reports */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-emerald-600" />
              Financial & Revenue
            </CardTitle>
            <CardDescription>Track profitability and sustainability of services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Revenue Analysis</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                Revenue by Procedure
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <CreditCard className="w-4 h-4 mr-2" />
                Cost per Case Analysis
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Payment Management</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <FileText className="w-4 h-4 mr-2" />
                Insurance & Self-pay Mix
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <Clock className="w-4 h-4 mr-2" />
                Outstanding Payments
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Patient Demographics & Population Health */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2 text-purple-600" />
              Demographics & Population Health
            </CardTitle>
            <CardDescription>Understand patient base and tailor services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start text-sm">
              <Users className="w-4 h-4 mr-2" />
              Age, Gender & Ethnicity
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <TrendingUp className="w-4 h-4 mr-2" />
              Referral Source Analysis
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <Activity className="w-4 h-4 mr-2" />
              Chronic Disease Overlap
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <MessageSquare className="w-4 h-4 mr-2" />
              Geographic Catchment
            </Button>
          </CardContent>
        </Card>

        {/* Regulatory & Compliance Dashboard */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-red-600" />
              Regulatory & Compliance
            </CardTitle>
            <CardDescription>Meet audit and governance obligations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start text-sm">
              <FileText className="w-4 h-4 mr-2" />
              National Cataract Audit
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <TrendingUp className="w-4 h-4 mr-2" />
              Visual Outcomes Registry
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <Activity className="w-4 h-4 mr-2" />
              Infection Control Compliance
            </Button>
            <Button variant="outline" className="w-full justify-start text-sm">
              <MessageSquare className="w-4 h-4 mr-2" />
              Safety Incident Reports
            </Button>
          </CardContent>
        </Card>

        {/* Patient Experience & Engagement */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-orange-600" />
              Patient Experience & Engagement
            </CardTitle>
            <CardDescription>Improve service quality from patient perspective</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Patient Outcomes</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                PROMs Analysis
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                PREMs Satisfaction
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Service Quality</h4>
              <Button variant="outline" className="w-full justify-start text-sm">
                <FileText className="w-4 h-4 mr-2" />
                Complaints/Compliments
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm">
                <UserCircle className="w-4 h-4 mr-2" />
                Portal Usage Adoption
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Example Dashboards Section */}
      <div className="mt-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Specialty Service Dashboards</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Cataract Service Dashboard */}
          <Card>
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center text-blue-800">
                <Eye className="w-5 h-5 mr-2" />
                Cataract Service
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">% achieving 6/12 or better</span>
                  <Badge className="bg-green-100 text-green-800">94.2%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Complication rates</span>
                  <Badge className="bg-yellow-100 text-yellow-800">1.8%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Cases per list</span>
                  <Badge className="bg-blue-100 text-blue-800">8.5</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Glaucoma Monitoring Dashboard */}
          <Card>
            <CardHeader className="bg-green-50">
              <CardTitle className="flex items-center text-green-800">
                <TrendingUp className="w-5 h-5 mr-2" />
                Glaucoma Monitoring
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">% controlled IOP</span>
                  <Badge className="bg-green-100 text-green-800">87.3%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">VF progression alerts</span>
                  <Badge className="bg-red-100 text-red-800">12</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Follow-up adherence</span>
                  <Badge className="bg-blue-100 text-blue-800">91.7%</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Retina Service Dashboard */}
          <Card>
            <CardHeader className="bg-purple-50">
              <CardTitle className="flex items-center text-purple-800">
                <TestTube className="w-5 h-5 mr-2" />
                Retina Service
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Injections/month</span>
                  <Badge className="bg-purple-100 text-purple-800">247</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Visual improvement</span>
                  <Badge className="bg-green-100 text-green-800">73.4%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Lost to follow-up</span>
                  <Badge className="bg-yellow-100 text-yellow-800">5.2%</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// Navigation Component
function Navigation({ currentPage, setCurrentPage }) {
  const navItems = [
    { id: 'dashboard', label: 'Reception Dashboard', icon: Activity },
    { id: 'appointments', label: 'Appointment Booking', icon: Calendar },
    { id: 'patients', label: 'Patient Records', icon: Users },
    { id: 'notes', label: 'Clinical Examination', icon: Stethoscope },
    { id: 'billing', label: 'Billing', icon: CreditCard },
    { id: 'messaging', label: 'Team Messenger', icon: MessageSquare },
    { id: 'portal', label: 'Patient Portal', icon: UserCircle },
    { id: 'bi-suite', label: 'BI Suite', icon: TrendingUp },
  ]

  const apiSoftware = [
    { id: 'optiscribe', label: 'OptiScribe', icon: FileText },
    { id: 'optix', label: 'Optix', icon: Eye },
    { id: 'locumpal', label: 'LocumPal', icon: Users },
    { id: 'nec-rego', label: 'NEC Rego', icon: Settings },
  ]

  return (
    <nav className="bg-white border-r border-gray-200 w-64 min-h-screen">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <img src={ophthalmixLogo} alt="OPHTHALMIX" className="w-12 h-12 rounded-lg" />
          <div>
            <h2 className="text-xl font-bold text-primary">OPHTHALMIX</h2>
            <p className="text-sm text-gray-500">Practice Management</p>
          </div>
        </div>
        
        <ul className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.id}>
                <button
                  onClick={() => setCurrentPage(item.id)}
                  className={`w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors ${
                    currentPage === item.id
                      ? 'bg-primary text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </div>
                </button>
              </li>
            )
          })}
        </ul>

        {/* Horizontal separator line */}
        <div className="my-6 border-t border-gray-200"></div>

        {/* API Software Section */}
        <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
          <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <Settings className="w-4 h-4 mr-2" />
            API Software
          </h3>
          <ul className="space-y-1">
            {apiSoftware.map((item) => {
              const Icon = item.icon
              
              const handleClick = () => {
                // Handle internal preview pages for API Software items
                switch (item.id) {
                  case 'optix':
                    setCurrentPage('optix-preview')
                    break
                  case 'locumpal':
                    setCurrentPage('locumpal-preview')
                    break
                  case 'nec-rego':
                    setCurrentPage('necrego-preview')
                    break
                  default:
                    setCurrentPage(item.id)
                }
              }
              
              return (
                <li key={item.id}>
                  <button
                    onClick={handleClick}
                    className={`w-full flex items-center px-3 py-2 rounded text-left transition-colors text-sm ${
                      currentPage === item.id
                        ? 'bg-primary text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </div>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    </nav>
  )
}

// API Software Preview Components
function OptixPreview() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">OptixHub</h1>
          <p className="text-gray-600 mt-1">Customer Log In Portal</p>
        </div>
        <div className="flex space-x-2">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Practice Management
          </Badge>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Customer Portal
          </Badge>
        </div>
      </div>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>OptixHub Customer Login</CardTitle>
          <CardDescription>Access your Optix practice management system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center">
            <img 
              src="/optix-login.png" 
              alt="OptixHub Customer Login" 
              className="w-full max-w-2xl h-auto rounded-lg border shadow-sm"
            />
          </div>
          <div className="mt-6 text-center space-y-4">
            <p className="text-sm text-gray-600">
              <strong>OptixHub</strong> provides secure access to your optician practice management system with comprehensive patient records, appointment scheduling, and business analytics.
            </p>
            <div className="flex justify-center space-x-2">
              <Button 
                onClick={() => window.open('https://www.optix.co.uk/', '_blank')}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Visit OptixHub
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function LocumPalPreview() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">LocumPal</h1>
          <p className="text-gray-600 mt-1">Bridging Expertise with Opportunity</p>
        </div>
        <div className="flex space-x-2">
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            Shift Management
          </Badge>
          <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
            Healthcare Staffing
          </Badge>
        </div>
      </div>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>LocumPal Platform Access</CardTitle>
          <CardDescription>Connect healthcare professionals with opportunities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center">
            <img 
              src="/locumpal-login.png" 
              alt="LocumPal Login" 
              className="w-full max-w-2xl h-auto rounded-lg border shadow-sm"
            />
          </div>
          <div className="mt-6 text-center space-y-4">
            <p className="text-sm text-gray-600">
              <strong>LocumPal</strong> bridges expertise with opportunity, connecting qualified healthcare professionals with facilities needing temporary staffing solutions.
            </p>
            <div className="flex justify-center space-x-2">
              <Button 
                onClick={() => window.open('https://booking-doctors-shifts.deploypad.app/', '_blank')}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Access LocumPal Platform
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function NECRegoPreview() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Rego by NEC</h1>
          <p className="text-gray-600 mt-1">Referral Management System</p>
        </div>
        <div className="flex space-x-2">
          <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
            Referral Management
          </Badge>
          <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
            Healthcare Integration
          </Badge>
        </div>
      </div>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>NEC Rego System Access</CardTitle>
          <CardDescription>Advanced referral management for healthcare providers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center">
            <img 
              src="/necrego-login.png" 
              alt="NEC Rego Login" 
              className="w-full max-w-2xl h-auto rounded-lg border shadow-sm"
            />
          </div>
          <div className="mt-6 text-center space-y-4">
            <p className="text-sm text-gray-600">
              <strong>Rego by NEC</strong> provides intelligent referral management to help patients get to the right treatment fast through streamlined healthcare workflows.
            </p>
            <div className="flex justify-center space-x-2">
              <Button 
                onClick={() => window.open('https://ref.management/login', '_blank')}
                className="bg-teal-600 hover:bg-teal-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Access NEC Rego System
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Main App Component
function App() {
  const [currentPage, setCurrentPage] = useState('dashboard')

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />
      case 'appointments':
        return <AppointmentBooking />
      case 'patients':
        return <PatientRecords />
      case 'notes':
        return <ClinicalNotes />
      case 'billing':
        return <Billing />
      case 'messaging':
        return <TeamMessenger />
      case 'portal':
        return <PatientPortalPage />
      case 'bi-suite':
        return <BISuite />
      case 'optiscribe':
        return <OptiScribe />
      case 'optix-preview':
        return <OptixPreview />
      case 'locumpal-preview':
        return <LocumPalPreview />
      case 'necrego-preview':
        return <NECRegoPreview />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="flex-1 p-8">
        {renderPage()}
      </main>
    </div>
  )
}

export default App

