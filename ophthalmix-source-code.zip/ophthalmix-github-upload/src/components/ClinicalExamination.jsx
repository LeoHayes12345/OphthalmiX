import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Save, FileText, Eye, Stethoscope } from 'lucide-react';
import PreliminaryDiagnostics from './PreliminaryDiagnostics';

const ClinicalExamination = ({ patientId, appointmentId }) => {
  const [activeTab, setActiveTab] = useState('history');
  const [isRecording, setIsRecording] = useState(false);
  const [showReportOptions, setShowReportOptions] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showEmailConfirm, setShowEmailConfirm] = useState(false);
  const [reportType, setReportType] = useState('');
  const [examinationData, setExaminationData] = useState({
    // History & Symptoms
    reasonForVisit: '',
    historySymptoms: '',
    presentingComplaints: '',
    pastOcularHistory: '',
    familyHistory: '',
    systemicConditions: '',
    currentMedications: '',
    lifestyleFactors: '',
    
    // Ophthalmic Examination
    lidsLashes: '',
    cornea: { od: '', os: '' },
    anteriorChamber: { od: '', os: '' },
    gonioscopy: { od: '', os: '' },
    iris: { od: '', os: '' },
    crystallineLens: { 
      od: { status: 'no_cataract', details: '' },
      os: { status: 'no_cataract', details: '' }
    },
    vitreousPosterior: { od: '', os: '' },
    opticNerveHead: { od: '', os: '' },
    macula: { od: '', os: '' },
    restOfFundus: { od: '', os: '' },
    
    // Summary & Plan
    diagnoses: [],
    treatmentsInitiated: [],
    reviewPlan: '',
    commentsForGP: '',
    aiDifferentialDiagnosis: []
  });

  const handleInputChange = (field, value, eye = null) => {
    setExaminationData(prev => {
      const newData = { ...prev };
      if (eye && typeof newData[field] === 'object' && !Array.isArray(newData[field])) {
        newData[field][eye] = value;
      } else {
        newData[field] = value;
      }
      return newData;
    });
  };

  const startRecording = () => {
    setIsRecording(true);
    // Implement voice recording functionality
    console.log('Starting voice recording...');
  };

  const stopRecording = () => {
    setIsRecording(false);
    // Implement voice recording stop and transcription
    console.log('Stopping voice recording...');
  };

  const saveExamination = async () => {
    try {
      const response = await fetch('/api/examinations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patientId,
          appointment_id: appointmentId,
          examination_data: examinationData
        })
      });
      
      if (response.ok) {
        alert('Examination saved successfully!');
      }
    } catch (error) {
      console.error('Error saving examination:', error);
      alert('Error saving examination');
    }
  };

  const generateAIDifferentialDiagnosis = () => {
    // Simulate AI differential diagnosis generation
    const mockDiagnoses = [
      'Primary open-angle glaucoma',
      'Cataract',
      'Age-related macular degeneration',
      'Vitreous detachment'
    ];
    
    setExaminationData(prev => ({
      ...prev,
      aiDifferentialDiagnosis: mockDiagnoses
    }));
  };

  const generateReport = (type) => {
    setReportType(type);
    setShowReport(true);
    setShowReportOptions(false);
  };

  const handleEmailReport = async (action) => {
    setShowEmailConfirm(false);
    
    try {
      if (reportType === 'gp') {
        if (action === 'send') {
          // Send email to GP
          alert('Report successfully emailed to GP at: dr.smith@medicalpractice.co.uk');
        }
      } else {
        if (action === 'send') {
          // Send email to patient
          alert('Report successfully emailed to patient at: mrs.smith@email.com');
        } else if (action === 'portal') {
          // Add to patient portal
          alert('Report successfully added to patient portal for Mrs Smith to view');
        }
      }
    } catch (error) {
      alert('Error sending email. Please try again.');
    }
  };

  const handleAddToPortal = async () => {
    try {
      // Add report directly to patient portal
      alert('Report successfully added to patient portal for Mrs Smith to view');
    } catch (error) {
      alert('Error adding report to portal. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Eye className="h-8 w-8 text-teal-600" />
            <h1 className="text-2xl font-bold text-gray-900">Ophthalmic Examination</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              variant={isRecording ? "destructive" : "outline"}
              onClick={isRecording ? stopRecording : startRecording}
              className="flex items-center space-x-2"
            >
              {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              <span>{isRecording ? 'Stop Recording' : 'Start AI Dictation'}</span>
            </Button>
            <Button onClick={saveExamination} className="bg-teal-600 hover:bg-teal-700">
              <Save className="h-4 w-4 mr-2" />
              Save Examination
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-teal-50 p-1">
            <TabsTrigger 
              value="diagnostics"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              PRELIMINARY DIAGNOSTICS
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              OPHTHALMIC EXAMINATION
            </TabsTrigger>
            <TabsTrigger 
              value="surgical"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              SURGICAL RECORDS
            </TabsTrigger>
            <TabsTrigger 
              value="summary"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              SUMMARY
            </TabsTrigger>
          </TabsList>

          {/* History & Symptoms Tab */}
          <TabsContent value="history" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">History and Symptoms</CardTitle>
                  <p className="text-sm text-gray-600">Use AI dictation to capture patient history naturally</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Reason for Visit</Label>
                    <Input
                      value={examinationData.reasonForVisit}
                      onChange={(e) => handleInputChange('reasonForVisit', e.target.value)}
                      placeholder="e.g., Blurred vision, routine check-up"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-gray-700">History of Present Illness</Label>
                    <Textarea
                      value={examinationData.historySymptoms}
                      onChange={(e) => handleInputChange('historySymptoms', e.target.value)}
                      placeholder="Describe the patient's current symptoms, onset, duration, and progression..."
                      className="mt-1 min-h-[120px]"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Past Ocular History</Label>
                      <Textarea
                        value={examinationData.pastOcularHistory}
                        onChange={(e) => handleInputChange('pastOcularHistory', e.target.value)}
                        placeholder="Previous eye conditions, surgeries, treatments..."
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Family History</Label>
                      <Textarea
                        value={examinationData.familyHistory}
                        onChange={(e) => handleInputChange('familyHistory', e.target.value)}
                        placeholder="Family history of eye conditions, glaucoma, diabetes..."
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Systemic Conditions</Label>
                      <Textarea
                        value={examinationData.systemicConditions}
                        onChange={(e) => handleInputChange('systemicConditions', e.target.value)}
                        placeholder="Diabetes, hypertension, autoimmune conditions..."
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Current Medications</Label>
                      <Textarea
                        value={examinationData.currentMedications}
                        onChange={(e) => handleInputChange('currentMedications', e.target.value)}
                        placeholder="List current medications and dosages..."
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Lifestyle Factors</Label>
                    <Textarea
                      value={examinationData.lifestyleFactors}
                      onChange={(e) => handleInputChange('lifestyleFactors', e.target.value)}
                      placeholder="Occupation, computer use, smoking, contact lens wear, driving requirements..."
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Clinical Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Clinical Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Header Row */}
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-teal-700 bg-teal-50 py-2 px-4 rounded-lg">
                        Right Eye (OD)
                      </h3>
                    </div>
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-blue-700 bg-blue-50 py-2 px-4 rounded-lg">
                        Left Eye (OS)
                      </h3>
                    </div>
                  </div>

                  {/* Lids/Lashes */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Lids/Lashes</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.lidsLashes?.od || ''}
                        onChange={(e) => handleInputChange('lidsLashes', e.target.value, 'od')}
                        placeholder="Mild blepharitis in upper lids"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.lidsLashes?.os || ''}
                        onChange={(e) => handleInputChange('lidsLashes', e.target.value, 'os')}
                        placeholder="Mild blepharitis in upper lids"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Cornea */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Cornea</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.cornea?.od || ''}
                        onChange={(e) => handleInputChange('cornea', e.target.value, 'od')}
                        placeholder="Clear cornea, no staining"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.cornea?.os || ''}
                        onChange={(e) => handleInputChange('cornea', e.target.value, 'os')}
                        placeholder="Clear cornea, no staining"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Anterior Chamber */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Anterior Chamber</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.anteriorChamber?.od || ''}
                        onChange={(e) => handleInputChange('anteriorChamber', e.target.value, 'od')}
                        placeholder="Deep and quiet"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.anteriorChamber?.os || ''}
                        onChange={(e) => handleInputChange('anteriorChamber', e.target.value, 'os')}
                        placeholder="Deep and quiet"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Gonioscopy */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Gonioscopy</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.gonioscopy?.od || ''}
                        onChange={(e) => handleInputChange('gonioscopy', e.target.value, 'od')}
                        placeholder="Open angles, no synechiae"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.gonioscopy?.os || ''}
                        onChange={(e) => handleInputChange('gonioscopy', e.target.value, 'os')}
                        placeholder="Open angles, no synechiae"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Iris & Angle */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Iris & Angle</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.iris?.od || ''}
                        onChange={(e) => handleInputChange('iris', e.target.value, 'od')}
                        placeholder="Normal iris (flat contour)"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.iris?.os || ''}
                        onChange={(e) => handleInputChange('iris', e.target.value, 'os')}
                        placeholder="Normal iris (flat contour)"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Crystalline Lens */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Crystalline Lens</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-2">
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="no_cataract_od"
                              name="lens_status_od"
                              value="no_cataract"
                              checked={examinationData.crystallineLens?.od?.status === 'no_cataract'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'od')}
                            />
                            <Label htmlFor="no_cataract_od" className="text-xs">No cataract</Label>
                          </div>
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="cataract_od"
                              name="lens_status_od"
                              value="cataract"
                              checked={examinationData.crystallineLens?.od?.status === 'cataract'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'od')}
                            />
                            <Label htmlFor="cataract_od" className="text-xs">Cataract</Label>
                          </div>
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="pseudophakic_od"
                              name="lens_status_od"
                              value="pseudophakic"
                              checked={examinationData.crystallineLens?.od?.status === 'pseudophakic'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'od')}
                            />
                            <Label htmlFor="pseudophakic_od" className="text-xs">Pseudophakic</Label>
                          </div>
                        </div>
                        <Input
                          value={examinationData.crystallineLens?.od?.details || ''}
                          onChange={(e) => handleInputChange('crystallineLens', { ...examinationData.crystallineLens?.od, details: e.target.value }, 'od')}
                          placeholder="Additional lens details"
                          className="border-teal-200 focus:border-teal-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-2">
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="no_cataract_os"
                              name="lens_status_os"
                              value="no_cataract"
                              checked={examinationData.crystallineLens?.os?.status === 'no_cataract'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'os')}
                            />
                            <Label htmlFor="no_cataract_os" className="text-xs">No cataract</Label>
                          </div>
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="cataract_os"
                              name="lens_status_os"
                              value="cataract"
                              checked={examinationData.crystallineLens?.os?.status === 'cataract'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'os')}
                            />
                            <Label htmlFor="cataract_os" className="text-xs">Cataract</Label>
                          </div>
                          <div className="flex items-center space-x-1">
                            <input
                              type="radio"
                              id="pseudophakic_os"
                              name="lens_status_os"
                              value="pseudophakic"
                              checked={examinationData.crystallineLens?.os?.status === 'pseudophakic'}
                              onChange={(e) => handleInputChange('crystallineLens', { status: e.target.value }, 'os')}
                            />
                            <Label htmlFor="pseudophakic_os" className="text-xs">Pseudophakic</Label>
                          </div>
                        </div>
                        <Input
                          value={examinationData.crystallineLens?.os?.details || ''}
                          onChange={(e) => handleInputChange('crystallineLens', { ...examinationData.crystallineLens?.os, details: e.target.value }, 'os')}
                          placeholder="Additional lens details"
                          className="border-blue-200 focus:border-blue-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Vitreous & Posterior Segment */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Vitreous & Posterior Segment</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.vitreousPosterior?.od || ''}
                        onChange={(e) => handleInputChange('vitreousPosterior', e.target.value, 'od')}
                        placeholder="Vitreous clear, retina flat-attached"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.vitreousPosterior?.os || ''}
                        onChange={(e) => handleInputChange('vitreousPosterior', e.target.value, 'os')}
                        placeholder="Vitreous clear, retina flat-attached"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Optic Nerve Head */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Optic Nerve Head</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.opticNerveHead?.od || ''}
                        onChange={(e) => handleInputChange('opticNerveHead', e.target.value, 'od')}
                        placeholder="Healthy optic disc with CDR 0.3"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.opticNerveHead?.os || ''}
                        onChange={(e) => handleInputChange('opticNerveHead', e.target.value, 'os')}
                        placeholder="Healthy optic disc with CDR 0.3"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Macula */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Macula</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.macula?.od || ''}
                        onChange={(e) => handleInputChange('macula', e.target.value, 'od')}
                        placeholder="Normal foveal reflex, no edema"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.macula?.os || ''}
                        onChange={(e) => handleInputChange('macula', e.target.value, 'os')}
                        placeholder="Normal foveal reflex, no edema"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Rest of Fundus/Retina */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Rest of Fundus/Retina</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        value={examinationData.restOfFundus?.od || ''}
                        onChange={(e) => handleInputChange('restOfFundus', e.target.value, 'od')}
                        placeholder="Retina normal, no peripheral lesions"
                        className="border-teal-200 focus:border-teal-500"
                      />
                      <Input
                        value={examinationData.restOfFundus?.os || ''}
                        onChange={(e) => handleInputChange('restOfFundus', e.target.value, 'os')}
                        placeholder="Retina normal, no peripheral lesions"
                        className="border-blue-200 focus:border-blue-500"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Preliminary Diagnostics Tab */}
          <TabsContent value="diagnostics" className="mt-6">
            <PreliminaryDiagnostics patientId={patientId} examinationId={null} />
          </TabsContent>

          {/* Surgical Records Tab */}
          <TabsContent value="surgical" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Surgical Records</CardTitle>
                  <p className="text-sm text-gray-600">Document surgical procedures and outcomes</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Surgical History */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Previous Surgical History</Label>
                    <Textarea
                      placeholder="Previous eye surgeries, dates, outcomes, complications..."
                      className="min-h-[100px]"
                    />
                  </div>

                  {/* Current Surgical Plan */}
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-teal-700 bg-teal-50 py-2 px-4 rounded-lg mb-4">
                        Right Eye (OD) Surgical Plan
                      </h3>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Procedure Planned</Label>
                          <Input
                            placeholder="e.g., Cataract extraction with IOL implantation"
                            className="mt-1 border-teal-200 focus:border-teal-500"
                          />
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Urgency</Label>
                          <select className="w-full mt-1 p-2 border border-teal-200 rounded-md focus:border-teal-500">
                            <option value="">Select urgency</option>
                            <option value="routine">Routine</option>
                            <option value="semi-urgent">Semi-urgent</option>
                            <option value="urgent">Urgent</option>
                            <option value="emergency">Emergency</option>
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Target Date</Label>
                          <Input
                            type="date"
                            className="mt-1 border-teal-200 focus:border-teal-500"
                          />
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Surgical Notes</Label>
                          <Textarea
                            placeholder="Pre-operative notes, special considerations..."
                            className="mt-1 border-teal-200 focus:border-teal-500"
                            rows={3}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-blue-700 bg-blue-50 py-2 px-4 rounded-lg mb-4">
                        Left Eye (OS) Surgical Plan
                      </h3>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Procedure Planned</Label>
                          <Input
                            placeholder="e.g., Cataract extraction with IOL implantation"
                            className="mt-1 border-blue-200 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Urgency</Label>
                          <select className="w-full mt-1 p-2 border border-blue-200 rounded-md focus:border-blue-500">
                            <option value="">Select urgency</option>
                            <option value="routine">Routine</option>
                            <option value="semi-urgent">Semi-urgent</option>
                            <option value="urgent">Urgent</option>
                            <option value="emergency">Emergency</option>
                          </select>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Target Date</Label>
                          <Input
                            type="date"
                            className="mt-1 border-blue-200 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-gray-700">Surgical Notes</Label>
                          <Textarea
                            placeholder="Pre-operative notes, special considerations..."
                            className="mt-1 border-blue-200 focus:border-blue-500"
                            rows={3}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Post-Operative Care */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Post-Operative Care Plan</Label>
                    <Textarea
                      placeholder="Post-operative medications, follow-up schedule, activity restrictions..."
                      className="min-h-[100px]"
                    />
                  </div>

                  {/* Surgical Outcomes */}
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Surgical Outcomes & Complications</Label>
                    <Textarea
                      placeholder="Document surgical outcomes, visual acuity improvements, complications if any..."
                      className="min-h-[100px]"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Summary Tab */}
          <TabsContent value="summary" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Summary */}
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900">Summary & Plan</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Reason for visit</Label>
                      <Input
                        value="Blurred vision"
                        className="mt-1 bg-gray-50"
                        readOnly
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Previous History of Ophthalmic Surgery</Label>
                      <Input
                        value="Left eye cataract surgery in 2017"
                        className="mt-1 bg-blue-50 border-blue-200"
                        readOnly
                        placeholder="Information carried over from Surgical Records"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Diagnosis</Label>
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                          <span className="text-sm">POAG</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                          <span className="text-sm">Cataract (right eye)</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                          <span className="text-sm">Dry AMD</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Treatments initiated</Label>
                      <div className="mt-2">
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                          <span className="text-sm">Latanoprost</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Review plan</Label>
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                          <span className="text-sm">Follow-up in 3 months</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                          <span className="text-sm">Consider cataract surgery (right eye)</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Comments for GP</Label>
                      <Textarea
                        value="Please monitor blood pressure"
                        className="mt-1"
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* AI Differential Diagnosis */}
              <div>
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg font-semibold text-gray-900">AI Differential Diagnosis</CardTitle>
                      <Badge variant="secondary" className="text-xs">OpenAI</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                        <span className="text-sm">Primary open-angle glaucoma</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                        <span className="text-sm">Cataract</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                        <span className="text-sm">Age-related macular degeneration</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                        <span className="text-sm">Vitreous detachment</span>
                      </div>
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-4"
                      onClick={generateAIDifferentialDiagnosis}
                    >
                      <Stethoscope className="h-4 w-4 mr-2" />
                      Refresh AI Analysis
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            {/* Generate Clinic Report Button */}
            <div className="flex justify-end mt-6">
              <div className="relative">
                <Button
                  variant="default"
                  className="bg-teal-600 hover:bg-teal-700 text-white"
                  onClick={() => setShowReportOptions(!showReportOptions)}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Clinic Report
                </Button>
                
                {showReportOptions && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="py-1">
                      <button
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => generateReport('patient')}
                      >
                        Generate Patient Report
                      </button>
                      <button
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => generateReport('gp')}
                      >
                        Generate GP Report
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Report Modal */}
            {showReport && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-gray-900">
                      {reportType === 'patient' ? 'Patient Report' : 'GP Report'}
                    </h2>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowReport(false)}
                    >
                      Close
                    </Button>
                  </div>
                  
                  <div className="bg-white border border-gray-300 p-8 font-serif text-sm leading-relaxed">
                    {/* Letter Header */}
                    <div className="text-center mb-8">
                      <h1 className="text-2xl font-bold text-teal-700 mb-2">CES Medical</h1>
                      <h2 className="text-xl font-semibold text-gray-700 mb-1">Chatham Eye Clinic and Surgery Centre</h2>
                      <div className="text-gray-600">
                        <p>123 Medical Centre Drive, Chatham, Kent ME4 5XX</p>
                        <p>Tel: 01634 123456 | Email: info@cesmedical.co.uk</p>
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-lg font-bold text-center text-gray-800 mb-4">Ophthalmology Report</h3>
                      <p className="text-right text-gray-600 mb-4">Date: {new Date().toLocaleDateString('en-GB')}</p>
                    </div>
                    
                    {/* Letter Content */}
                    <div className="space-y-4">
                      {reportType === 'gp' ? (
                        <>
                          <p>Dear Dr ......,</p>
                          <p>I saw Mrs Smith today and these were my findings:</p>
                        </>
                      ) : (
                        <>
                          <p>Dear Mrs Smith,</p>
                          <p>It was a pleasure to see you today. As discussed these are my findings:</p>
                        </>
                      )}
                      
                      <div className="ml-4 space-y-3">
                        <p><strong>Reason for visit:</strong> Blurred vision</p>
                        <p><strong>Previous History of Ophthalmic Surgery:</strong> Left eye cataract surgery in 2017</p>
                        
                        <div>
                          <p><strong>Diagnosis:</strong></p>
                          <ul className="ml-4 list-disc">
                            <li>POAG (Primary Open-Angle Glaucoma)</li>
                            <li>Cataract (right eye)</li>
                            <li>Dry AMD (Age-related Macular Degeneration)</li>
                          </ul>
                        </div>
                        
                        <div>
                          <p><strong>Treatments initiated:</strong></p>
                          <ul className="ml-4 list-disc">
                            <li>Latanoprost</li>
                          </ul>
                        </div>
                        
                        <div>
                          <p><strong>Review plan:</strong></p>
                          <ul className="ml-4 list-disc">
                            <li>Follow-up in 3 months</li>
                            <li>Consider cataract surgery (right eye)</li>
                          </ul>
                        </div>
                        
                        {reportType === 'gp' && (
                          <p><strong>Comments for GP:</strong> Please monitor blood pressure</p>
                        )}
                      </div>
                      
                      <div className="mt-8 pt-4">
                        <p>Yours sincerely,</p>
                        <div className="mt-8">
                          <p className="font-semibold">Typed but not Signed</p>
                          <p className="font-bold">Mr Elion Hyseni</p>
                          <p>Consultant Optometrist</p>
                          <p className="text-sm text-gray-600 mt-2">CES Medical, Chatham Eye Clinic and Surgery Centre</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-4 space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => window.print()}
                    >
                      Print Report
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={() => setShowEmailConfirm(true)}
                    >
                      Email Report
                    </Button>
                    {reportType === 'patient' && (
                      <Button
                        variant="outline"
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                        onClick={() => handleAddToPortal()}
                      >
                        Add to Portal
                      </Button>
                    )}
                    <Button
                      variant="default"
                      className="bg-teal-600 hover:bg-teal-700"
                      onClick={() => setShowReport(false)}
                    >
                      Close
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Email Confirmation Modal */}
            {showEmailConfirm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60">
                <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">
                      {reportType === 'gp' ? 'Email to GP?' : 'Email to Patient?'}
                    </h3>
                    <p className="text-gray-600 mb-6">
                      {reportType === 'gp' 
                        ? 'Send this report directly to the patient\'s GP?' 
                        : 'How would you like to share this report with the patient?'
                      }
                    </p>
                    
                    <div className="flex justify-center space-x-3">
                      {reportType === 'gp' ? (
                        <>
                          <Button
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleEmailReport('send')}
                          >
                            Yes
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => setShowEmailConfirm(false)}
                          >
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleEmailReport('send')}
                          >
                            Yes
                          </Button>
                          <Button
                            variant="outline"
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                            onClick={() => handleEmailReport('portal')}
                          >
                            No, just Add to Portal
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ClinicalExamination;

