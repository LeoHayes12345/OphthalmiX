import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar, 
  FileText, 
  MessageCircle, 
  CreditCard, 
  User, 
  Eye, 
  Clock, 
  CheckCircle, 
  XCircle,
  ChevronRight,
  Download,
  Send
} from 'lucide-react';

const PatientPortal = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [messages, setMessages] = useState([
    {
      id: 1,
      from: 'Dr. Adams',
      subject: 'Regarding appointment',
      preview: 'Your next appointment is scheduled for...',
      date: '2025-07-25',
      isRead: false
    }
  ]);
  
  const [newMessage, setNewMessage] = useState({
    subject: '',
    message: ''
  });

  const patientData = {
    name: 'John Smith',
    nextAppointment: {
      type: 'Eye Exam',
      date: 'Monday, Jul 25, 2025',
      time: '10:00 AM',
      doctor: 'Dr. Adams'
    },
    recentTests: [
      {
        name: 'Visual Field Test',
        date: 'Jul 25, 2025',
        result: 'Normal',
        status: 'completed'
      },
      {
        name: 'OCT Scan',
        date: 'Jul 20, 2025',
        result: 'Mild Changes',
        status: 'completed'
      }
    ],
    billing: {
      outstandingAmount: 200,
      dueDate: 'Jul 30',
      invoices: [
        {
          id: 'INV-001',
          date: '2025-07-25',
          amount: 200,
          description: 'Comprehensive Eye Exam',
          status: 'outstanding'
        }
      ]
    }
  };

  const sendMessage = () => {
    if (newMessage.subject && newMessage.message) {
      // Simulate sending message
      alert('Message sent successfully!');
      setNewMessage({ subject: '', message: '' });
    }
  };

  const confirmAppointment = () => {
    alert('Appointment confirmed!');
  };

  const cancelAppointment = () => {
    alert('Appointment cancelled. You will receive a confirmation email.');
  };

  const payNow = () => {
    alert('Redirecting to secure payment gateway...');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center">
                  <Eye className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">OphthalmiX</h1>
                  <p className="text-xs text-gray-500">Patient Portal</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">Welcome, {patientData.name}</p>
                <p className="text-xs text-gray-500">Patient ID: #12345</p>
              </div>
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <User className="h-5 w-5 text-gray-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white border border-gray-200 p-1">
            <TabsTrigger 
              value="dashboard" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Dashboard
            </TabsTrigger>
            <TabsTrigger 
              value="appointments"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Appointments
            </TabsTrigger>
            <TabsTrigger 
              value="results"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Test Results
            </TabsTrigger>
            <TabsTrigger 
              value="messages"
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Messages
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              {/* Appointments */}
              <Card className="md:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-teal-600" />
                    Appointments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Next Appointmet</p>
                      <p className="text-sm font-medium text-teal-600">{patientData.nextAppointment.type}</p>
                      <p className="text-xs text-gray-500">{patientData.nextAppointment.date}</p>
                      <p className="text-xs text-gray-500">{patientData.nextAppointment.time}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        className="bg-teal-600 hover:bg-teal-700 text-xs px-3 py-1"
                        onClick={confirmAppointment}
                      >
                        Confirm
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs px-3 py-1"
                        onClick={cancelAppointment}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Test Results */}
              <Card className="md:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-teal-600" />
                    Test Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Recent Tests</p>
                      <div className="space-y-2 mt-2">
                        {patientData.recentTests.slice(0, 2).map((test, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div>
                              <p className="text-xs font-medium text-gray-700">{test.name}</p>
                              <p className="text-xs text-gray-500">{test.date}</p>
                            </div>
                            <Badge 
                              variant={test.result === 'Normal' ? 'secondary' : 'destructive'}
                              className="text-xs"
                            >
                              {test.result}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full text-xs"
                      onClick={() => setActiveTab('results')}
                    >
                      View All
                      <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Prescriptions */}
              <Card className="md:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                    <Eye className="h-5 w-5 mr-2 text-teal-600" />
                    Prescriptions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Current Prescriptions</p>
                      <div className="space-y-2 mt-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-xs font-medium text-gray-700">Latanoprost</p>
                            <p className="text-xs text-gray-500">Eye drops - Daily</p>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            Active
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-xs font-medium text-gray-700">Timolol</p>
                            <p className="text-xs text-gray-500">Eye drops - Twice daily</p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            Expired
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full text-xs"
                    >
                      View All Prescriptions
                      <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Messages */}
              <Card className="md:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                    <MessageCircle className="h-5 w-5 mr-2 text-teal-600" />
                    Messages
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Inbox</p>
                      {messages.length > 0 ? (
                        <div className="mt-2">
                          <div className="space-y-2">
                            <div>
                              <p className="text-xs font-medium text-gray-700">{messages[0].from}</p>
                              <p className="text-xs text-gray-500">{messages[0].subject}</p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs text-gray-500 mt-2">No new messages</p>
                      )}
                    </div>
                    <Button 
                      className="w-full bg-teal-600 hover:bg-teal-700 text-xs"
                      onClick={() => setActiveTab('messages')}
                    >
                      Message Clinic
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Billing */}
              <Card className="md:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
                    <CreditCard className="h-5 w-5 mr-2 text-teal-600" />
                    Billing
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Outstanding Invoice</p>
                      <p className="text-2xl font-bold text-gray-900">£{patientData.billing.outstandingAmount}</p>
                      <p className="text-xs text-gray-500">Due {patientData.billing.dueDate}</p>
                    </div>
                    <Button 
                      className="w-full bg-green-600 hover:bg-green-700 text-xs"
                      onClick={payNow}
                    >
                      Pay Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Appointments Tab */}
          <TabsContent value="appointments" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Upcoming Appointments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                          <Calendar className="h-6 w-6 text-teal-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{patientData.nextAppointment.type}</p>
                          <p className="text-sm text-gray-500">{patientData.nextAppointment.date} at {patientData.nextAppointment.time}</p>
                          <p className="text-sm text-gray-500">with {patientData.nextAppointment.doctor}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" className="bg-teal-600 hover:bg-teal-700">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Confirm
                        </Button>
                        <Button variant="outline" size="sm">
                          <XCircle className="h-4 w-4 mr-1" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">Request New Appointment</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Appointment Type</Label>
                      <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500">
                        <option>Routine Eye Exam</option>
                        <option>Follow-up Visit</option>
                        <option>Contact Lens Fitting</option>
                        <option>Emergency Consultation</option>
                      </select>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Preferred Date</Label>
                      <Input type="date" className="mt-1" />
                    </div>
                    <div className="md:col-span-2">
                      <Label className="text-sm font-medium text-gray-700">Reason for Visit</Label>
                      <Textarea 
                        placeholder="Please describe your symptoms or reason for the appointment..."
                        className="mt-1"
                        rows={3}
                      />
                    </div>
                  </div>
                  <Button className="mt-4 bg-teal-600 hover:bg-teal-700">
                    Submit Request
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Test Results Tab */}
          <TabsContent value="results" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Test Results & Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {patientData.recentTests.map((test, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <FileText className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{test.name}</p>
                          <p className="text-sm text-gray-500">{test.date}</p>
                          <Badge 
                            variant={test.result === 'Normal' ? 'secondary' : 'destructive'}
                            className="mt-1"
                          >
                            {test.result}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Message List */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900">Messages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {messages.map((message) => (
                        <div key={message.id} className="p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="font-medium text-gray-900 text-sm">{message.from}</p>
                              <p className="text-sm text-gray-600 truncate">{message.subject}</p>
                              <p className="text-xs text-gray-500 mt-1">{message.date}</p>
                            </div>
                            {!message.isRead && (
                              <div className="w-2 h-2 bg-teal-600 rounded-full"></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Compose Message */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900">Send Message to Clinic</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Subject</Label>
                        <Input
                          value={newMessage.subject}
                          onChange={(e) => setNewMessage({...newMessage, subject: e.target.value})}
                          placeholder="Enter message subject..."
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Message</Label>
                        <Textarea
                          value={newMessage.message}
                          onChange={(e) => setNewMessage({...newMessage, message: e.target.value})}
                          placeholder="Type your message here..."
                          className="mt-1"
                          rows={6}
                        />
                      </div>
                      <Button 
                        onClick={sendMessage}
                        className="bg-teal-600 hover:bg-teal-700"
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Send Message
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                <Eye className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">OphthalmiX</h3>
            </div>
            <p className="text-sm text-gray-500">OPHTHALMOLOGY SOFTWARE</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PatientPortal;

