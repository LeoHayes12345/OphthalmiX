import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Eye, Camera, Upload, Save, FileText, Brain, Zap } from 'lucide-react';
import visualFieldExample from '../assets/visual_field_example.jpeg';
import octExample from '../assets/oct_example.jpeg';
import octRnflExample from '../assets/oct_rnfl_example.jpeg';
import widefieldExample from '../assets/widefield_example.jpeg';
import widefieldLeftExample from '../assets/widefield_left_example.webp';

const PreliminaryDiagnostics = ({ patientId, examinationId }) => {
  const [diagnosticsData, setDiagnosticsData] = useState({
    // Visual Acuity
    visualAcuity: {
      od_unaided: '',
      os_unaided: '',
      od_corrected: '',
      os_corrected: '',
      od_pinhole: '',
      os_pinhole: ''
    },
    
    // Spectacles/Contact Lens Prescription
    wearsGlasses: false,
    wearsContactLenses: false,
    existingRx: {
      od: { sphere: '', cylinder: '', axis: '' },
      os: { sphere: '', cylinder: '', axis: '' }
    },
    
    // Intraocular Pressure
    iop: {
      od: '',
      os: '',
      instrument: 'Goldmann',
      time: ''
    },
    
    // Visual Fields
    visualFields: {
      od: {
        strategy: '24-2',
        result: 'normal',
        defectType: '',
        notes: ''
      },
      os: {
        strategy: '24-2',
        result: 'normal',
        defectType: '',
        notes: ''
      }
    },
    
    // OCT
    oct: {
      od: {
        centralThickness: '',
        rnflAverage: '',
        findings: '',
        normal: true
      },
      os: {
        centralThickness: '',
        rnflAverage: '',
        findings: '',
        normal: true
      }
    },
    
    // Biometry
    biometry: {
      od: {
        axialLength: '',
        acd: '',
        k1: '',
        k2: '',
        axis: ''
      },
      os: {
        axialLength: '',
        acd: '',
        k1: '',
        k2: '',
        axis: ''
      }
    },
    
    // Widefield Imaging
    widefield: {
      od: {
        findings: '',
        normal: true
      },
      os: {
        findings: '',
        normal: true
      }
    },
    
    // Other Tests
    otherTests: {
      colorVision: '',
      depthPerception: '',
      additionalNotes: ''
    }
  });

  const [images, setImages] = useState({
    visualFields: { od: null, os: null },
    oct: { od: null, os: null },
    widefield: { od: null, os: null }
  });

  const handleInputChange = (section, field, value, eye = null) => {
    setDiagnosticsData(prev => {
      const newData = { ...prev };
      if (eye) {
        if (!newData[section][eye]) newData[section][eye] = {};
        newData[section][eye][field] = value;
      } else if (section && field) {
        if (!newData[section]) newData[section] = {};
        newData[section][field] = value;
      } else {
        newData[section] = value;
      }
      return newData;
    });
  };

  const handleImageUpload = (testType, eye, file) => {
    setImages(prev => ({
      ...prev,
      [testType]: {
        ...prev[testType],
        [eye]: file
      }
    }));
  };

  const saveDiagnostics = async () => {
    try {
      const response = await fetch('/api/examinations/preliminary-diagnostics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patientId,
          examination_id: examinationId,
          diagnostics_data: diagnosticsData
        })
      });
      
      if (response.ok) {
        alert('Preliminary diagnostics saved successfully!');
      }
    } catch (error) {
      console.error('Error saving diagnostics:', error);
      alert('Error saving diagnostics');
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Eye className="h-8 w-8 text-teal-600" />
          <h1 className="text-2xl font-bold text-gray-900">Preliminary Diagnostics</h1>
        </div>
        <Button onClick={saveDiagnostics} className="bg-teal-600 hover:bg-teal-700">
          <Save className="h-4 w-4 mr-2" />
          Save Diagnostics
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Visual Acuity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Visual Acuity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-700">RVA</Label>
                <Input
                  value={diagnosticsData.visualAcuity.od_unaided}
                  onChange={(e) => handleInputChange('visualAcuity', 'od_unaided', e.target.value)}
                  placeholder="6/6"
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700">LVA with pinhole</Label>
                <Input
                  value={diagnosticsData.visualAcuity.os_pinhole}
                  onChange={(e) => handleInputChange('visualAcuity', 'os_pinhole', e.target.value)}
                  placeholder="6/6"
                  className="mt-1"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Spectacles/Contact Lens Prescription */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Spectacles / Contact Lens Prescription</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  checked={diagnosticsData.wearsGlasses}
                  onCheckedChange={(checked) => handleInputChange('wearsGlasses', null, checked)}
                />
                <Label className="text-sm">Wears glasses</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  checked={diagnosticsData.wearsContactLenses}
                  onCheckedChange={(checked) => handleInputChange('wearsContactLenses', null, checked)}
                />
                <Label className="text-sm">Wears contact lenses</Label>
              </div>
            </div>
            
            {diagnosticsData.wearsGlasses && (
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox defaultChecked />
                  <Label className="text-sm">Conselectacula purben</Label>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="-2.00 / -0.75 x 90" className="text-sm" />
                  <Input placeholder="-1.75 / -0.50 x 85" className="text-sm" />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Intraocular Pressure */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Intraocular Pressure</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox defaultChecked />
                  <Label className="text-sm">Right VA IOP</Label>
                </div>
                <Input
                  value={diagnosticsData.iop.od}
                  onChange={(e) => handleInputChange('iop', 'od', e.target.value)}
                  placeholder="20 mm Hg"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox defaultChecked />
                  <Label className="text-sm">Left VA IOP</Label>
                </div>
                <Input
                  value={diagnosticsData.iop.os}
                  onChange={(e) => handleInputChange('iop', 'os', e.target.value)}
                  placeholder="15 mm Hg"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-700">Instrument</Label>
                <Select value={diagnosticsData.iop.instrument} onValueChange={(value) => handleInputChange('iop', 'instrument', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Goldmann">Goldmann</SelectItem>
                    <SelectItem value="Icare">Icare</SelectItem>
                    <SelectItem value="NCT">NCT</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700">Time</Label>
                <Input
                  value={diagnosticsData.iop.time}
                  onChange={(e) => handleInputChange('iop', 'time', e.target.value)}
                  placeholder="11:30"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Insurment */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Insurment</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Normal macular visual loss"
              className="w-full"
            />
          </CardContent>
        </Card>

        {/* Visual Fields */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Visual Fields</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Right Humphrey</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-32 flex items-center justify-center">
                  {images.visualFields.od ? (
                    <img src={URL.createObjectURL(images.visualFields.od)} alt="Right VF" className="max-h-full" />
                  ) : (
                    <div className="text-center">
                      <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('vf-od-upload').click()}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Image
                      </Button>
                      <input
                        id="vf-od-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleImageUpload('visualFields', 'od', e.target.files[0])}
                      />
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">No significant visual field loss</p>
                  <p className="text-sm text-gray-600">Superior peripheral defect</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Left Humphrey</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-48 flex items-center justify-center relative">
                  {images.visualFields.os ? (
                    <img src={URL.createObjectURL(images.visualFields.os)} alt="Left VF" className="max-h-full" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <img 
                        src={visualFieldExample} 
                        alt="Visual Field Example - Superior Peripheral Defect" 
                        className="max-h-full max-w-full object-contain rounded"
                      />
                      <div className="absolute top-2 right-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById('vf-os-upload').click()}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Replace
                        </Button>
                        <input
                          id="vf-os-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleImageUpload('visualFields', 'os', e.target.files[0])}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600">Superior peripheral defect</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => analyzeVisualField('left')}
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-blue-600 mt-0.5" />
                      <div className="text-xs text-blue-800">
                        <p className="font-medium">AI Diagnostic Analysis:</p>
                        <p>• Superior arcuate defect consistent with glaucomatous field loss</p>
                        <p>• Respects horizontal meridian - suggests inferior optic nerve damage</p>
                        <p>• Recommend: OCT RNFL, optic disc assessment, IOP monitoring</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* OCT */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">OCT</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Right Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-48 flex items-center justify-center relative">
                  {images.oct?.od ? (
                    <img src={URL.createObjectURL(images.oct.od)} alt="Right Eye OCT" className="max-h-full max-w-full object-contain" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <img 
                        src={octExample} 
                        alt="OCT Macular Thickness Analysis - Right Eye" 
                        className="max-h-full max-w-full object-contain rounded"
                      />
                      <div className="absolute top-2 right-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById('oct-od-upload').click()}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Replace
                        </Button>
                        <input
                          id="oct-od-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleImageUpload('oct', 'od', e.target.files[0])}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Normal macular thickness</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => analyzeOCT('right')}
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                  <Badge variant="secondary" className="text-xs">Normal</Badge>
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-green-600 mt-0.5" />
                      <div className="text-xs text-green-800">
                        <p className="font-medium">AI OCT Analysis:</p>
                        <p>• Macular thickness within normal limits (255-323 μm)</p>
                        <p>• ILM-RPE integrity preserved</p>
                        <p>• No signs of macular edema or atrophy</p>
                        <p>• Foveal contour normal</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Left Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-48 flex items-center justify-center relative">
                  {images.oct?.os ? (
                    <img src={URL.createObjectURL(images.oct.os)} alt="Left Eye OCT" className="max-h-full max-w-full object-contain" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <img 
                        src={octRnflExample} 
                        alt="OCT RNFL Analysis - Left Eye Outside Normal Limits" 
                        className="max-h-full max-w-full object-contain rounded"
                      />
                      <div className="absolute top-2 right-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById('oct-os-upload').click()}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Replace
                        </Button>
                        <input
                          id="oct-os-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleImageUpload('oct', 'os', e.target.files[0])}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Thinning of retina nerve fiber layer</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => analyzeOCT('left')}
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                  <Badge variant="destructive" className="text-xs">Outside Normal Limits</Badge>
                  <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                    <div className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-red-600 mt-0.5" />
                      <div className="text-xs text-red-800">
                        <p className="font-medium">AI RNFL Analysis:</p>
                        <p>• Significant RNFL thinning in superior and inferior quadrants</p>
                        <p>• Asymmetry between OD (normal) and OS (abnormal)</p>
                        <p>• Pattern consistent with glaucomatous optic neuropathy</p>
                        <p>• Correlates with superior visual field defect</p>
                        <p>• Recommend: IOP control, serial monitoring, consider treatment escalation</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Biometry */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Biometry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Right Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-32 flex items-center justify-center">
                  {images.biometry?.od ? (
                    <img src={URL.createObjectURL(images.biometry.od)} alt="Right Eye Biometry" className="max-h-full max-w-full object-contain" />
                  ) : (
                    <div className="text-center">
                      <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('biometry-od-upload').click()}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Image
                      </Button>
                      <input
                        id="biometry-od-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleImageUpload('biometry', 'od', e.target.files[0])}
                      />
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <Label className="text-xs font-medium">Axial Length</Label>
                      <Input placeholder="23.45 mm" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">K1</Label>
                      <Input placeholder="43.25 D" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">K2</Label>
                      <Input placeholder="44.10 D" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">ACD</Label>
                      <Input placeholder="3.15 mm" className="h-8 text-xs" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Left Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-32 flex items-center justify-center">
                  {images.biometry?.os ? (
                    <img src={URL.createObjectURL(images.biometry.os)} alt="Left Eye Biometry" className="max-h-full max-w-full object-contain" />
                  ) : (
                    <div className="text-center">
                      <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('biometry-os-upload').click()}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Image
                      </Button>
                      <input
                        id="biometry-os-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleImageUpload('biometry', 'os', e.target.files[0])}
                      />
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <Label className="text-xs font-medium">Axial Length</Label>
                      <Input placeholder="23.52 mm" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">K1</Label>
                      <Input placeholder="43.18 D" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">K2</Label>
                      <Input placeholder="44.05 D" className="h-8 text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs font-medium">ACD</Label>
                      <Input placeholder="3.12 mm" className="h-8 text-xs" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Widefield */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Widefield</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Right Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-48 flex items-center justify-center relative">
                  {images.widefield?.od ? (
                    <img src={URL.createObjectURL(images.widefield.od)} alt="Right Eye Widefield" className="max-h-full max-w-full object-contain rounded" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <img 
                        src={widefieldExample} 
                        alt="Widefield Fundus - Right Eye Normal" 
                        className="max-h-full max-w-full object-contain rounded"
                      />
                      <div className="absolute top-2 right-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById('widefield-od-upload').click()}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Replace
                        </Button>
                        <input
                          id="widefield-od-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleImageUpload('widefield', 'od', e.target.files[0])}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600">Healthy retina, normal periphery</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => analyzeWidefield('right')}
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                  <Badge variant="secondary" className="text-xs">Normal</Badge>
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-green-600 mt-0.5" />
                      <div className="text-xs text-green-800">
                        <p className="font-medium">AI Widefield Analysis:</p>
                        <p>• Normal optic disc and macula appearance</p>
                        <p>• Healthy vascular pattern throughout</p>
                        <p>• No peripheral pathology detected</p>
                        <p>• Normal retinal pigmentation</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Left Eye</h4>
                <div className="bg-gray-100 rounded-lg p-4 h-48 flex items-center justify-center relative">
                  {images.widefield?.os ? (
                    <img src={URL.createObjectURL(images.widefield.os)} alt="Left Eye Widefield" className="max-h-full max-w-full object-contain rounded" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <img 
                        src={widefieldLeftExample} 
                        alt="Widefield Fundus - Left Eye with Peripheral Changes" 
                        className="max-h-full max-w-full object-contain rounded"
                      />
                      <div className="absolute top-2 right-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById('widefield-os-upload').click()}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Replace
                        </Button>
                        <input
                          id="widefield-os-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleImageUpload('widefield', 'os', e.target.files[0])}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600">Peripheral retinal changes noted</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => analyzeWidefield('left')}
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                  <Badge variant="destructive" className="text-xs">Abnormal</Badge>
                  <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                    <div className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-orange-600 mt-0.5" />
                      <div className="text-xs text-orange-800">
                        <p className="font-medium">AI Widefield Analysis:</p>
                        <p>• Peripheral retinal pathology detected</p>
                        <p>• Possible lattice degeneration or peripheral breaks</p>
                        <p>• Fluorescence pattern suggests vascular changes</p>
                        <p>• Recommend: Detailed peripheral examination, possible treatment</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Other Tests */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Other Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Colour vision, depth perception etc."
              value={diagnosticsData.otherTests.additionalNotes}
              onChange={(e) => handleInputChange('otherTests', 'additionalNotes', e.target.value)}
              className="min-h-[80px]"
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // AI Analysis Functions
  const analyzeVisualField = async (eye) => {
    // Placeholder for AI visual field analysis
    console.log(`Analyzing visual field for ${eye} eye`);
    // In production, this would call the AI analysis API
  };

  const analyzeOCT = async (eye) => {
    // Placeholder for AI OCT analysis
    console.log(`Analyzing OCT for ${eye} eye`);
    // In production, this would call the AI analysis API
  };

  const analyzeWidefield = async (eye) => {
    // Placeholder for AI widefield analysis
    console.log(`Analyzing widefield for ${eye} eye`);
    // In production, this would call the AI analysis API
  };
};

export default PreliminaryDiagnostics;

